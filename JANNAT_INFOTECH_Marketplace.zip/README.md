# JANNAT INFOTECH Marketplace

A full-stack Alibaba-inspired marketplace starter with:
- Public storefront with search, categories, featured products, cart and checkout
- Admin panel at `/admin`
- Product/category management
- Custom/manual payment methods (COD, UPI/manual, bank transfer, gateway placeholder)
- Order management and payment-status management
- Store settings/banner/contact editing
- Server-Sent Events (SSE) for live updates: admin changes and new orders are pushed to connected storefront/admin pages
- JSON persistence in `data.json`
- Responsive UI

## Run

1. Install Node.js 18+.
2. Open this project folder.
3. Run:
   `npm install`
4. Run:
   `npm start`
5. Open:
   `http://localhost:3000`
6. Admin:
   `http://localhost:3000/admin`

Default admin token:
`JANNAT-ADMIN-2026`

For production, set an environment variable:
`ADMIN_TOKEN=your-strong-secret`

## Production notes

This starter is intentionally easy to run. Before handling real money or large traffic, replace JSON storage with PostgreSQL/MySQL, add proper user/admin authentication and password hashing, CSRF/rate-limit protections, object storage for product images, audit logs, HTTPS, and a verified payment gateway such as Razorpay/Stripe or another provider appropriate for your business. The admin payment-method editor is designed so gateway details can be added without changing the storefront structure.
