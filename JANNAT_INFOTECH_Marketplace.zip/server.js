const express = require("express");
const path = require("path");
const fs = require("fs");
const multer = require("multer");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA = path.join(ROOT, "data.json");
const PUBLIC = path.join(ROOT, "public");
const upload = multer({ dest: path.join(ROOT, "public/uploads") });

app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(PUBLIC));

const defaultData = {
  settings: {
    storeName: "JANNAT INFOTECH",
    tagline: "Everything you need. One trusted marketplace.",
    logoText: "JANNAT",
    heroTitle: "Shop smarter. Discover more.",
    heroSubtitle: "Quality products, competitive prices and a simple buying experience.",
    announcement: "Welcome to JANNAT INFOTECH — Fast delivery • Secure checkout • Trusted sellers",
    currency: "₹",
    supportPhone: "+91 00000 00000",
    supportEmail: "support@jannatinfotech.com"
  },
  categories: [
    { id: "cat-electronics", name: "Electronics", icon: "💻" },
    { id: "cat-mobile", name: "Mobiles & Accessories", icon: "📱" },
    { id: "cat-office", name: "Office & Stationery", icon: "🖨️" },
    { id: "cat-computers", name: "Computers", icon: "🖥️" },
    { id: "cat-home", name: "Home & Lifestyle", icon: "🏠" },
    { id: "cat-network", name: "Networking", icon: "📡" }
  ],
  products: [
    { id:"p1", name:"Wireless Keyboard & Mouse Combo", category:"Electronics", price:1299, oldPrice:1799, stock:42, rating:4.7, badge:"Best Seller", image:"https://images.unsplash.com/photo-1587829741301-dc798b83add3?auto=format&fit=crop&w=900&q=80", description:"Comfortable wireless keyboard and mouse set for home and office." },
    { id:"p2", name:"Business Laptop 14-inch", category:"Computers", price:48999, oldPrice:54999, stock:12, rating:4.8, badge:"Hot Deal", image:"https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=900&q=80", description:"Slim business laptop with a crisp display and long battery life." },
    { id:"p3", name:"USB-C Fast Charger 65W", category:"Mobiles & Accessories", price:1499, oldPrice:1999, stock:65, rating:4.6, badge:"Deal", image:"https://images.unsplash.com/photo-1583863788434-e58a36330cf0?auto=format&fit=crop&w=900&q=80", description:"Compact 65W USB-C charger for phones, tablets and laptops." },
    { id:"p4", name:"Wi-Fi 6 Dual Band Router", category:"Networking", price:2999, oldPrice:3999, stock:28, rating:4.5, badge:"New", image:"https://images.unsplash.com/photo-1606904825846-647eb07f5be5?auto=format&fit=crop&w=900&q=80", description:"Fast dual-band Wi-Fi 6 router for homes and small offices." },
    { id:"p5", name:"A4 Multifunction Printer", category:"Office & Stationery", price:8999, oldPrice:10499, stock:16, rating:4.4, badge:"Popular", image:"https://images.unsplash.com/photo-1612815154858-60aa4c59eaa6?auto=format&fit=crop&w=900&q=80", description:"Print, scan and copy with an efficient compact office printer." },
    { id:"p6", name:"Smart Desk Lamp", category:"Home & Lifestyle", price:999, oldPrice:1499, stock:74, rating:4.3, badge:"Value", image:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80", description:"Modern adjustable LED desk lamp with warm and cool modes." }
  ],
  paymentMethods: [
    { id:"cod", name:"Cash on Delivery", type:"cod", enabled:true, instructions:"Pay when your order arrives." },
    { id:"upi", name:"UPI / QR Payment", type:"manual", enabled:true, instructions:"Pay to our UPI ID and enter the transaction/reference ID during checkout.", upiId:"jannatinfotech@upi", qrImage:"" },
    { id:"bank", name:"Bank Transfer", type:"manual", enabled:false, instructions:"Admin can enter bank account details here." }
  ],
  orders: []
};

function load() {
  if (!fs.existsSync(DATA)) fs.writeFileSync(DATA, JSON.stringify(defaultData, null, 2));
  return JSON.parse(fs.readFileSync(DATA, "utf8"));
}
function save(db) { fs.writeFileSync(DATA, JSON.stringify(db, null, 2)); broadcast(); }
let db = load();
const clients = new Set();
function broadcast() {
  const payload = JSON.stringify({ type:"update", at:Date.now() });
  for (const res of clients) res.write(`data: ${payload}\n\n`);
}

function admin(req,res,next) {
  const token = req.headers["x-admin-token"] || req.query.token;
  if (token !== (process.env.ADMIN_TOKEN || "JANNAT-ADMIN-2026")) return res.status(401).json({error:"Unauthorized"});
  next();
}

app.get("/api/store", (req,res) => {
  db = load();
  res.json({ settings:db.settings, categories:db.categories, products:db.products, paymentMethods:db.paymentMethods.filter(p=>p.enabled) });
});

app.get("/api/admin", admin, (req,res) => {
  db = load();
  res.json(db);
});

app.get("/api/events", (req,res) => {
  res.setHeader("Content-Type","text/event-stream");
  res.setHeader("Cache-Control","no-cache");
  res.setHeader("Connection","keep-alive");
  res.flushHeaders();
  res.write(`data: ${JSON.stringify({type:"connected"})}\n\n`);
  clients.add(res);
  req.on("close", () => clients.delete(res));
});

app.post("/api/orders", (req,res) => {
  const { customer, items, paymentMethod, paymentReference, total } = req.body;
  if (!customer?.name || !customer?.phone || !customer?.address || !items?.length) return res.status(400).json({error:"Missing checkout information"});
  db = load();
  const order = {
    id: "JI-" + Date.now().toString(36).toUpperCase() + "-" + crypto.randomBytes(2).toString("hex").toUpperCase(),
    createdAt: new Date().toISOString(),
    customer, items, paymentMethod, paymentReference: paymentReference || "", total:Number(total)||0,
    status:"Pending", paymentStatus: paymentMethod === "cod" ? "Pending" : "Verification Pending"
  };
  db.orders.unshift(order);
  for (const item of items) {
    const p = db.products.find(x=>x.id===item.id);
    if (p) p.stock = Math.max(0, Number(p.stock) - Number(item.qty));
  }
  save(db);
  res.json({ok:true, order});
});

app.put("/api/admin/settings", admin, (req,res) => {
  db = load(); db.settings = {...db.settings, ...req.body}; save(db); res.json(db.settings);
});
app.post("/api/admin/products", admin, (req,res) => {
  db = load();
  const p = {...req.body, id:req.body.id || "p_"+Date.now()};
  p.price = Number(p.price)||0; p.oldPrice = Number(p.oldPrice)||0; p.stock = Number(p.stock)||0;
  db.products.unshift(p); save(db); res.json(p);
});
app.put("/api/admin/products/:id", admin, (req,res) => {
  db = load(); const i=db.products.findIndex(p=>p.id===req.params.id);
  if(i<0) return res.status(404).json({error:"Product not found"});
  db.products[i]={...db.products[i],...req.body}; save(db); res.json(db.products[i]);
});
app.delete("/api/admin/products/:id", admin, (req,res) => {
  db = load(); db.products=db.products.filter(p=>p.id!==req.params.id); save(db); res.json({ok:true});
});
app.post("/api/admin/categories", admin, (req,res) => {
  db=load(); const c={...req.body,id:req.body.id||"cat_"+Date.now()}; db.categories.push(c); save(db); res.json(c);
});
app.delete("/api/admin/categories/:id", admin, (req,res) => {
  db=load(); db.categories=db.categories.filter(c=>c.id!==req.params.id); save(db); res.json({ok:true});
});
app.post("/api/admin/payments", admin, (req,res) => {
  db=load(); const p={...req.body,id:req.body.id||"pay_"+Date.now(),enabled:req.body.enabled!==false}; db.paymentMethods.push(p); save(db); res.json(p);
});
app.put("/api/admin/payments/:id", admin, (req,res) => {
  db=load(); const i=db.paymentMethods.findIndex(p=>p.id===req.params.id);
  if(i<0) return res.status(404).json({error:"Payment method not found"});
  db.paymentMethods[i]={...db.paymentMethods[i],...req.body}; save(db); res.json(db.paymentMethods[i]);
});
app.delete("/api/admin/payments/:id", admin, (req,res) => {
  db=load(); db.paymentMethods=db.paymentMethods.filter(p=>p.id!==req.params.id); save(db); res.json({ok:true});
});
app.put("/api/admin/orders/:id", admin, (req,res) => {
  db=load(); const i=db.orders.findIndex(o=>o.id===req.params.id);
  if(i<0) return res.status(404).json({error:"Order not found"});
  db.orders[i]={...db.orders[i],...req.body}; save(db); res.json(db.orders[i]);
});

app.post("/api/admin/upload", admin, upload.single("image"), (req,res) => {
  if(!req.file) return res.status(400).json({error:"No image"});
  const ext = path.extname(req.file.originalname) || ".jpg";
  const target = path.join(PUBLIC,"uploads",req.file.filename+ext);
  fs.renameSync(req.file.path,target);
  res.json({url:"/uploads/"+path.basename(target)});
});

app.get("/admin", (req,res) => res.sendFile(path.join(PUBLIC,"admin.html")));
app.get("*", (req,res) => res.sendFile(path.join(PUBLIC,"index.html")));

app.listen(PORT, ()=>console.log(`JANNAT INFOTECH running on http://localhost:${PORT}`));
