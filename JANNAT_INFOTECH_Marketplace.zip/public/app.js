let store={}; let cart=JSON.parse(localStorage.getItem("ji-cart")||"[]");
const $=id=>document.getElementById(id);
const money=n=>(store.settings?.currency||"₹")+Number(n||0).toLocaleString("en-IN");
async function loadStore(){ store=await fetch("/api/store").then(r=>r.json()); render(); }
function render(){
 $("announcement").textContent=store.settings?.announcement||"";
 $("brandName").textContent=store.settings?.storeName||"JANNAT INFOTECH";
 $("footerName").textContent=store.settings?.storeName||"JANNAT INFOTECH";
 $("heroTitle").textContent=store.settings?.heroTitle||"Shop smarter. Discover more.";
 $("heroSubtitle").textContent=store.settings?.heroSubtitle||"";
 $("support").textContent=(store.settings?.supportPhone||"")+" • "+(store.settings?.supportEmail||"");
 $("categories").innerHTML=(store.categories||[]).map(c=>`<button onclick='filterCat(${JSON.stringify(c.name)})'>${c.icon||"•"} ${esc(c.name)}</button>`).join("");
 const cf=$("categoryFilter"), old=cf.value; cf.innerHTML='<option value="">All categories</option>'+(store.categories||[]).map(c=>`<option>${esc(c.name)}</option>`).join(""); cf.value=old;
 const q=($("search").value||"").toLowerCase(), cat=cf.value;
 const ps=(store.products||[]).filter(p=>(!q||(p.name+" "+p.category+" "+p.description).toLowerCase().includes(q))&&(!cat||p.category===cat));
 $("productGrid").innerHTML=ps.map(card).join("")||'<div class="empty">No products found.</div>'; updateCart();
}
function filterCat(c){$("categoryFilter").value=c;render();document.querySelector("#products").scrollIntoView({behavior:"smooth"});}
function card(p){return `<article class="product"><div class="product-img">${p.badge?`<span class="badge">${esc(p.badge)}</span>`:""}<img src="${esc(p.image||"https://placehold.co/700x520?text=JANNAT+INFOTECH")}" alt="${esc(p.name)}"></div><div class="pbody"><div class="cat">${esc(p.category||"General")}</div><h3>${esc(p.name)}</h3><div class="rating">★ ${Number(p.rating||0).toFixed(1)}</div><p>${esc(p.description||"")}</p><div class="price"><b>${money(p.price)}</b>${p.oldPrice?`<del>${money(p.oldPrice)}</del>`:""}</div><div class="stock">${Number(p.stock)>0?`${p.stock} in stock`:"Out of stock"}</div><button class="primary full" ${p.stock<=0?"disabled":""} onclick="addToCart('${p.id}')">Add to cart</button></div></article>`}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));}
function addToCart(id){const p=store.products.find(x=>x.id===id);if(!p)return;const x=cart.find(i=>i.id===id);if(x)x.qty++;else cart.push({id,qty:1});saveCart();openCart();}
function saveCart(){localStorage.setItem("ji-cart",JSON.stringify(cart));updateCart();}
function updateCart(){$("cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0);$("cartItems").innerHTML=cart.length?cart.map(i=>{let p=store.products.find(x=>x.id===i.id);return p?`<div class="cart-row"><img src="${esc(p.image)}"><div><b>${esc(p.name)}</b><small>${money(p.price)} × ${i.qty}</small><div><button onclick="changeQty('${p.id}',-1)">−</button> <b>${i.qty}</b> <button onclick="changeQty('${p.id}',1)">+</button></div></div><strong>${money(p.price*i.qty)}</strong></div>`:""}).join(""):'<div class="empty">Your cart is empty.</div>';$("cartTotal").textContent=money(cart.reduce((a,i)=>a+(store.products.find(p=>p.id===i.id)?.price||0)*i.qty,0);}
function changeQty(id,d){let x=cart.find(i=>i.id===id);if(x){x.qty+=d;if(x.qty<=0)cart=cart.filter(i=>i.id!==id);saveCart();}}
function openCart(){$("cartDrawer").classList.add("open")} function closeCart(){$("cartDrawer").classList.remove("open")}
function checkout(){if(!cart.length)return alert("Add a product first."); closeCart(); $("paymentSelect").innerHTML=(store.paymentMethods||[]).map(p=>`<option value="${esc(p.id)}">${esc(p.name)}</option>`).join(""); paymentChanged(); $("checkoutModal").classList.add("open");}
function closeCheckout(){$("checkoutModal").classList.remove("open")}
function paymentChanged(){const p=store.paymentMethods.find(x=>x.id===$("paymentSelect").value);$("paymentInstructions").textContent=p?.instructions||"";}
$("paymentSelect").addEventListener("change",paymentChanged);
$("checkoutForm").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.target), items=cart.map(i=>({id:i.id,qty:i.qty,name:store.products.find(p=>p.id===i.id)?.name,price:store.products.find(p=>p.id===i.id)?.price}));const total=items.reduce((a,i)=>a+i.price*i.qty,0);const body={customer:{name:f.get("name"),phone:f.get("phone"),address:f.get("address")},items,paymentMethod:f.get("payment"),paymentReference:f.get("reference"),total};const r=await fetch("/api/orders",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});const x=await r.json();if(!r.ok)return alert(x.error||"Could not place order");cart=[];saveCart();e.target.classList.add("hidden");$("orderSuccess").classList.remove("hidden");$("orderSuccess").innerHTML=`<h3>Order placed 🎉</h3><p>Your order ID is <b>${esc(x.order.id)}</b>.</p><p>We will contact you at ${esc(x.order.customer.phone)} with updates.</p>`;});
$("search").addEventListener("input",render);
const ev=new EventSource("/api/events"); ev.onmessage=e=>{try{const x=JSON.parse(e.data);if(x.type==="update")loadStore()}catch{}};
loadStore();
